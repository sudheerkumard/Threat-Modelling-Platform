## Overview
Customer self-service portal for an insurance company. ~200k registered customers, business criticality High.
Handles PII and policy documents (Confidential). In scope for GDPR and ISO 27001.

## Components & hosting (Azure, East US + Japan East DR)
- Azure Front Door Premium with WAF policy (Prevention mode, Microsoft Default Rule Set 2.1)
- Web front end: Azure App Service (Linux, .NET 8), VNet-integrated
- API layer: Azure Container Apps (3 microservices: policy, claims, documents)
- Data: Azure SQL Database (policies, customers), Azure Storage (claim documents), Azure Cache for Redis (sessions)
- Messaging: Azure Event Hubs -> Azure Databricks for fraud analytics
- AI: Azure OpenAI (GPT-4o) RAG assistant over policy wording using Azure AI Search (vector index)
- Secrets: Azure Key Vault

## Identity & access
- Customers: Entra External ID, email + password, MFA optional
- Services: Managed Identity for SQL and Storage; Redis uses access key; Event Hubs uses SAS connection string
- Admins: Entra ID with PIM for Owner/Contributor; break-glass account exists

## Network
- Private endpoints for SQL, Storage, Key Vault, AI Search
- Redis and Event Hubs have public network access enabled (IP firewall)
- Databricks workspace without VNet injection
- Site-to-site VPN to on-prem claims system (SOAP over HTTPS)

## Data flows
1. Customer -> Front Door (HTTPS) -> App Service (HTTPS, Front Door ID header validated)
2. App Service -> Container Apps APIs (HTTPS, JWT)
3. APIs -> SQL (TDS/TLS, Managed Identity), Storage (HTTPS, MI), Redis (TLS 6380, access key)
4. Claims API -> Event Hubs (AMQP, SAS) -> Databricks
5. Assistant: App Service -> Azure OpenAI + AI Search (API keys)
6. Claims API -> on-prem claims system over VPN

## Existing security controls
- Defender for Cloud (Servers, SQL, Storage, Key Vault plans); Sentinel with Entra ID and Azure Activity connectors
- GitHub Actions with OIDC to Azure; Dependabot enabled; no image signing
- Daily SQL backups, geo-redundant storage; no documented DR test
