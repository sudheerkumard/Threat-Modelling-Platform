# Dot-sourced by ThreatModel.Engine.psm1 - builds the standalone HTML report.

function Get-TopLevelControl {
    param([string]$Framework, [string]$Ref)
    $r = $Ref.Trim()
    switch ($Framework) {
        'CIS'        { if ($r -match '(\d{1,2})') { return "CIS $([int]$Matches[1])" } }
        'NIST_CSF'   { if ($r -match '([A-Z]{2}\.[A-Z]{2})') { return $Matches[1] } }
        'NIST_80053' { if ($r -match '^([A-Z]{2})') { return $Matches[1] } }
        'MCSB'       { if ($r -match '^([A-Z]{2})') { return $Matches[1] } }
        'OWASP'      { if ($r -match 'A(\d{1,2})') { return ('A{0:D2}:2025' -f [int]$Matches[1]) } }
        'OWASP_LLM'  { if ($r -match 'LLM(\d{1,2})') { return ('LLM{0:D2}:2025' -f [int]$Matches[1]) } }
    }
    return $r
}

function New-ThreatReportHtml {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][System.Collections.IDictionary]$Model,
        [Parameter(Mandatory)][string]$Mermaid,
        [Parameter(Mandatory)][object]$Catalog,
        [string]$AssessmentPath
    )
    $H = { param($v) ConvertTo-HtmlSafe $v }
    $m = $Model.metrics
    $meta = $Model.meta
    $frameworks = @($meta.frameworks)
    $strideName = [ordered]@{ S = 'Spoofing'; T = 'Tampering'; R = 'Repudiation'; I = 'Information Disclosure'; D = 'Denial of Service'; E = 'Elevation of Privilege' }
    $compName = @{}; foreach ($c in $Model.components) { $compName[$c.id] = $c.name }
    $sevClass = { param($s) "sev-$(([string]$s).ToLower())" }

    $sb = [System.Text.StringBuilder]::new()
    $A = { param($s) [void]$sb.AppendLine($s) }

    # ---------- Head ----------
    $title = "Threat Model - $($Model.systemName)"
    & $A '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
    & $A "<title>$(& $H $title)</title>"
    & $A '<style>'
    & $A (Get-ReportCss)
    & $A '</style></head><body>'

    # ---------- Header ----------
    $fwChips = ($frameworks | ForEach-Object { $fw = Get-PropValue $Catalog $_; "<span class='chip'>$(& $H $fw.name) $(& $H $fw.version)</span>" }) -join ''
    $created = try { ([datetime]$meta.generatedAt).ToLocalTime().ToString('dd MMM yyyy HH:mm') } catch { $meta.generatedAt }
    & $A @"
<header class="hdr">
  <div class="hdr-inner">
    <div>
      <div class="eyebrow">AI-Assisted Threat Model · STRIDE</div>
      <h1>$(& $H $Model.systemName)</h1>
      <div class="hdr-meta">
        <span>ID <b>$(& $H $meta.assessmentId)</b></span>
        <span>Environment <b>$(& $H $meta.environment)</b></span>
        <span>Criticality <b>$(& $H $meta.criticality)</b></span>
        <span>Data <b>$(& $H $meta.dataClassification)</b></span>
        <span>Owner <b>$(& $H $meta.owner)</b></span>
        <span>Generated <b>$(& $H $created)</b></span>
      </div>
      <div class="chips">$fwChips</div>
    </div>
    <div class="hdr-actions no-print"><button onclick="window.print()">Print / Save PDF</button></div>
  </div>
  <nav class="toc no-print">
    <a href="#summary">Summary</a><a href="#map">Threat map</a><a href="#arch">Architecture</a><a href="#heat">Heatmap</a>
    <a href="#matrix">Risk matrix</a><a href="#threats">Threats</a><a href="#gaps">Gaps</a><a href="#coverage">Framework mapping</a><a href="#appendix">Appendix</a>
  </nav>
</header>
<main>
"@

    # ---------- KPIs & summary ----------
    $tbs = $m.threatsBySeverity; $gbs = $m.gapsBySeverity
    $bar = {
        param($counts)
        $total = 0; foreach ($k in $counts.Keys) { $total += $counts[$k] }
        if ($total -eq 0) { return "<div class='sevbar'></div>" }
        $segs = foreach ($k in 'Critical','High','Medium','Low') { if ($counts[$k]) { "<span class='$(& $sevClass $k)' style='flex:$($counts[$k])' title='${k}: $($counts[$k])'>$($counts[$k])</span>" } }
        "<div class='sevbar'>$($segs -join '')</div>"
    }
    $conf = $Model.confidence
    & $A @"
<section id="summary">
  <div class="kpis">
    <div class="kpi kpi-score $(& $sevClass $m.exposureRating)-border">
      <div class="kpi-label">Exposure score</div>
      <div class="kpi-val">$($m.exposureScore)<small>/100</small></div>
      <div class="kpi-sub"><span class="pill $(& $sevClass $m.exposureRating)">$(& $H $m.exposureRating)</span></div>
    </div>
    <div class="kpi"><div class="kpi-label">Threats identified</div><div class="kpi-val">$($m.totalThreats)</div>$(& $bar $tbs)</div>
    <div class="kpi"><div class="kpi-label">Control gaps</div><div class="kpi-val">$($m.totalGaps)</div>$(& $bar $gbs)</div>
    <div class="kpi"><div class="kpi-label">Scope</div><div class="kpi-val">$($m.totalComponents)<small> components</small></div><div class="kpi-sub">$($m.totalFlows) data flows · $(@($Model.trustBoundaries).Count) trust boundaries</div></div>
  </div>
  <div class="grid2">
    <div class="card"><h2>Executive summary</h2><p>$(& $H $Model.executiveSummary)</p>
      <p class="muted small">Analysis confidence: <b>$(& $H $conf.level)</b>. $(& $H $conf.notes)</p></div>
    <div class="card"><h2>Threats by STRIDE category</h2><div class="stride-bars">
"@
    $maxS = [math]::Max(1, (@($m.threatsByStride.Values) | Measure-Object -Maximum).Maximum)
    foreach ($k in $strideName.Keys) {
        $v = $m.threatsByStride[$k]; $w = [math]::Round(100 * $v / $maxS)
        & $A "<div class='sb-row'><span class='sb-k'>$k</span><span class='sb-n'>$($strideName[$k])</span><span class='sb-track'><span class='sb-fill' style='width:$w%'></span></span><span class='sb-v'>$v</span></div>"
    }
    & $A '</div></div></div>'

    # Top risks
    $top = @($Model.threats | Select-Object -First 5)
    if ($top.Count) {
        & $A '<div class="card"><h2>Top risks</h2><ol class="toprisks">'
        foreach ($t in $top) {
            $comps = (@($t.componentIds | ForEach-Object { $compName[$_] }) -join ', ')
            & $A "<li><span class='pill $(& $sevClass $t.severity)'>$($t.severity) · $($t.riskScore)</span> <b>$($t.id)</b> $(& $H $t.title) <span class='muted'>— $(& $H $comps)</span></li>"
        }
        & $A '</ol></div>'
    }
    & $A '</section>'

    # ---------- Threat map ----------
    & $A @"
<section id="map">
  <div class="sec-head"><h2>Threat mapping diagram</h2>
    <div class="no-print"><button onclick="downloadSvg()">Download SVG</button></div></div>
  <p class="muted">Data-flow diagram reconstructed from the inputs. Components are coloured by their highest-severity threat; thick arrows cross a trust boundary; ⚠ lists threat IDs (see the threat register); 🔓 marks unencrypted flows.</p>
  <div class="legend">
    <span><i class="sw sev-critical"></i>Critical</span><span><i class="sw sev-high"></i>High</span><span><i class="sw sev-medium"></i>Medium</span><span><i class="sw sev-low"></i>Low</span><span><i class="sw sev-none"></i>No threat</span>
    <span class="muted">Shapes: ▱ external entity · ▭ process · ⛁ data store · ⬡ identity provider</span>
  </div>
  <div class="diagram card"><pre class="mermaid" id="threatmap">
$(& $H $Mermaid)
  </pre><div id="mm-fallback" class="muted small" hidden>Diagram could not be rendered (no internet access to the Mermaid library). The diagram source is in <code>diagram.mmd</code> — paste it into mermaid.live.</div></div>
</section>
"@

    # ---------- Architecture ----------
    & $A '<section id="arch"><h2>Architecture as analysed</h2><div class="grid2"><div class="card">'
    & $A "<h3>Understanding</h3><p>$(& $H $Model.architectureUnderstanding)</p>"
    & $A '<h3>Trust boundaries</h3><ul>'
    foreach ($tb in $Model.trustBoundaries) { & $A "<li><b>$(& $H $tb.id) · $(& $H $tb.name)</b> — $(& $H $tb.description)</li>" }
    & $A '</ul></div><div class="card"><h3>Submitted inputs</h3>'
    $embedded = 0
    if ($AssessmentPath) {
        foreach ($f in @($meta.images)) {
            $p = Join-Path $AssessmentPath (Join-Path 'input' $f)
            if ((Test-Path -LiteralPath $p) -and (Get-Item -LiteralPath $p).Length -lt 6MB) {
                $ext = [IO.Path]::GetExtension($p).TrimStart('.').ToLower(); if ($ext -eq 'jpg') { $ext = 'jpeg' }
                & $A "<figure><img class='archimg' alt='Submitted architecture' src='data:image/$ext;base64,$([Convert]::ToBase64String([IO.File]::ReadAllBytes($p)))'><figcaption>$(& $H $f)</figcaption></figure>"
                $embedded++
            }
        }
    }
    if ($embedded -eq 0) { & $A '<p class="muted">No architecture image submitted.</p>' }
    & $A "<p class='muted small'>Text summary supplied: <b>$(if ($meta.hasSummary) { 'Yes' } else { 'No' })</b></p></div></div></section>"

    # ---------- STRIDE heatmap ----------
    & $A '<section id="heat"><h2>STRIDE × component heatmap</h2><div class="card scroll"><table class="heat"><thead><tr><th>Component</th>'
    foreach ($k in $strideName.Keys) { & $A "<th title='$($strideName[$k])'>$k<div class='small muted'>$($strideName[$k])</div></th>" }
    & $A '<th>Total</th></tr></thead><tbody>'
    foreach ($c in $Model.components) {
        $ct = @($Model.threats | Where-Object { $_.componentIds -contains $c.id })
        & $A "<tr><td><b>$(& $H $c.name)</b><div class='small muted'>$(& $H $c.technology)</div></td>"
        foreach ($k in $strideName.Keys) {
            $cell = @($ct | Where-Object { $_.stride -contains $k })
            if ($cell.Count) {
                $mx = ($cell | Sort-Object { -(Get-SeverityRank $_.severity) } | Select-Object -First 1).severity
                & $A "<td class='hc $(& $sevClass $mx)' title='$(& $H ((@($cell | ForEach-Object { $_.id })) -join ', '))'>$($cell.Count)</td>"
            } else { & $A "<td class='hc empty'>·</td>" }
        }
        & $A "<td class='hc-total'>$($ct.Count)</td></tr>"
    }
    & $A '</tbody></table></div></section>'

    # ---------- Risk matrix ----------
    & $A '<section id="matrix"><h2>Risk matrix (likelihood × impact)</h2><div class="card scroll"><table class="riskm"><tbody>'
    for ($l = 5; $l -ge 1; $l--) {
        & $A "<tr><th class='axis'>L$l</th>"
        for ($i = 1; $i -le 5; $i++) {
            $ids = @($Model.threats | Where-Object { $_.likelihood -eq $l -and $_.impact -eq $i } | ForEach-Object { $_.id })
            $sev = Get-SeverityFromScore ($l * $i)
            & $A "<td class='rm $(& $sevClass $sev)-soft'><span class='rm-score'>$($l*$i)</span>$(& $H ($ids -join ' '))</td>"
        }
        & $A '</tr>'
    }
    & $A "<tr><th></th>$((1..5 | ForEach-Object { "<th class='axis'>I$_</th>" }) -join '')</tr></tbody></table>"
    & $A '<p class="muted small">L = likelihood (1 rare … 5 almost certain), I = impact (1 minimal … 5 severe). Score = L × I; Critical ≥ 20, High ≥ 12, Medium ≥ 6.</p></div></section>'

    # ---------- Threat register ----------
    $fwShort = @{ OWASP = 'OWASP'; OWASP_LLM = 'OWASP LLM'; CIS = 'CIS v8.1'; NIST_CSF = 'NIST CSF'; NIST_80053 = '800-53'; MCSB = 'MCSB' }
    $mapChips = {
        param($mappings)
        $parts = foreach ($f in $frameworks) {
            $refs = @($mappings[$f])
            if ($refs.Count) { "<div class='mapline'><span class='maplbl'>$($fwShort[$f])</span>$((($refs | ForEach-Object { "<span class='chip c-$($f.ToLower())'>$(& $H $_)</span>" }) -join ''))</div>" }
        }
        $parts -join ''
    }
    & $A @"
<section id="threats"><div class="sec-head"><h2>Threat register</h2>
<div class="filters no-print">
  <input id="tq" placeholder="Search threats…" oninput="filterThreats()">
  <select id="tsev" onchange="filterThreats()"><option value="">All severities</option><option>Critical</option><option>High</option><option>Medium</option><option>Low</option></select>
  <select id="tstr" onchange="filterThreats()"><option value="">All STRIDE</option>$((($strideName.Keys | ForEach-Object { "<option value='$_'>$_ · $($strideName[$_])</option>" }) -join ''))</select>
  <button onclick="toggleAll()">Expand / collapse</button>
</div></div>
<div class="card scroll"><table class="reg" id="treg"><thead><tr><th>ID</th><th>Threat</th><th>STRIDE</th><th>Component(s)</th><th>L</th><th>I</th><th>Risk</th></tr></thead><tbody>
"@
    foreach ($t in $Model.threats) {
        $comps = (@($t.componentIds | ForEach-Object { & $H $compName[$_] }) -join '<br>')
        $str = (($t.stride | ForEach-Object { "<span class='stride' title='$($strideName[$_])'>$_</span>" }) -join '')
        $search = & $H ("$($t.id) $($t.title) $($t.description) " + (@($t.componentIds | ForEach-Object { $compName[$_] }) -join ' ')).ToLower()
        & $A "<tr class='trow' data-sev='$($t.severity)' data-stride='$($t.stride -join '')' data-q='$search' onclick='toggleRow(this)'><td><b>$($t.id)</b></td><td>$(& $H $t.title)</td><td>$str</td><td>$comps</td><td>$($t.likelihood)</td><td>$($t.impact)</td><td><span class='pill $(& $sevClass $t.severity)'>$($t.severity) · $($t.riskScore)</span></td></tr>"
        $ec = if (@($t.existingControls).Count) { '<ul>' + ((@($t.existingControls) | ForEach-Object { "<li>$(& $H $_)</li>" }) -join '') + '</ul>' } else { '<p class="muted">None identified.</p>' }
        $mi = '<ul>' + ((@($t.mitigations) | ForEach-Object { "<li>$(& $H $_)</li>" }) -join '') + '</ul>'
        $flows = if (@($t.dataFlowIds).Count) { "<p class='small muted'>Data flows: $(& $H ($t.dataFlowIds -join ', '))</p>" } else { '' }
        & $A "<tr class='tdetail' hidden><td></td><td colspan='6'><div class='detail-grid'><div><h4>Description</h4><p>$(& $H $t.description)</p><h4>Attack scenario</h4><p>$(& $H $t.attackScenario)</p>$flows</div><div><h4>Existing controls</h4>$ec<h4>Recommended mitigations</h4>$mi</div><div><h4>Framework mapping</h4>$(& $mapChips $t.mappings)</div></div></td></tr>"
    }
    & $A '</tbody></table></div></section>'

    # ---------- Gaps ----------
    & $A '<section id="gaps"><h2>Gap analysis</h2>'
    # Roadmap columns
    & $A '<div class="roadmap">'
    foreach ($p in @(@('P1','Immediate (0-30 days)'), @('P2','Short term (30-90 days)'), @('P3','Planned (90+ days)'))) {
        $gs = @($Model.gaps | Where-Object { $_.priority -eq $p[0] })
        & $A "<div class='rm-col card'><h3>$($p[0]) · $($p[1]) <span class='muted'>($($gs.Count))</span></h3><ul>"
        foreach ($g in $gs) { & $A "<li><span class='dot $(& $sevClass $g.severity)'></span><b>$($g.id)</b> $(& $H $g.title)</li>" }
        & $A '</ul></div>'
    }
    & $A '</div>'
    foreach ($g in $Model.gaps) {
        $aff = (@($g.affectedComponentIds | ForEach-Object { $compName[$_] }) -join ', ')
        & $A @"
<article class="gap card $(& $sevClass $g.severity)-border">
  <div class="gap-head"><div><span class="gid">$($g.id)</span> <b>$(& $H $g.title)</b></div>
   <div><span class="pill $(& $sevClass $g.severity)">$($g.severity)</span> <span class="pill neutral">$($g.priority)</span> <span class="pill neutral">Effort: $(& $H $g.effort)</span> <span class="pill neutral">$(& $H $g.domain)</span></div></div>
  <div class="gap-grid">
    <div><h4>Observation</h4><p>$(& $H $g.observation)</p><h4>Risk</h4><p>$(& $H $g.risk)</p></div>
    <div><h4>Recommendation</h4><p>$(& $H $g.recommendation)</p>
      <p class="small muted">Related threats: $(& $H ($g.relatedThreatIds -join ', '))$(if ($aff) { " · Affects: $(& $H $aff)" })</p></div>
    <div><h4>Framework mapping</h4>$(& $mapChips $g.mappings)</div>
  </div>
</article>
"@
    }
    & $A '</section>'

    # ---------- Framework coverage ----------
    & $A '<section id="coverage"><h2>Framework mapping &amp; coverage</h2><p class="muted">Each control/category implicated by at least one threat or gap. Untouched controls are listed for completeness — they were not assessed as at-risk from the information supplied, which is not the same as being compliant.</p>'
    foreach ($f in $frameworks) {
        $fw = Get-PropValue $Catalog $f; if (-not $fw) { continue }
        $agg = @{}
        foreach ($t in $Model.threats) { foreach ($r in @($t.mappings[$f])) { $k = Get-TopLevelControl $f $r; if (-not $agg[$k]) { $agg[$k] = @{ T = [System.Collections.Generic.List[string]]::new(); G = [System.Collections.Generic.List[string]]::new(); S = 0; Refs = [System.Collections.Generic.HashSet[string]]::new() } }; $agg[$k].T.Add($t.id); [void]$agg[$k].Refs.Add($r); $agg[$k].S = [math]::Max($agg[$k].S, (Get-SeverityRank $t.severity)) } }
        foreach ($g in $Model.gaps)    { foreach ($r in @($g.mappings[$f])) { $k = Get-TopLevelControl $f $r; if (-not $agg[$k]) { $agg[$k] = @{ T = [System.Collections.Generic.List[string]]::new(); G = [System.Collections.Generic.List[string]]::new(); S = 0; Refs = [System.Collections.Generic.HashSet[string]]::new() } }; $agg[$k].G.Add($g.id); [void]$agg[$k].Refs.Add($r); $agg[$k].S = [math]::Max($agg[$k].S, (Get-SeverityRank $g.severity)) } }
        $hit = @($fw.items | Where-Object { $agg[$_.id] }).Count
        & $A "<details class='card fw' open><summary><b>$(& $H $fw.name) $(& $H $fw.version)</b> <span class='muted'>— $hit of $(@($fw.items).Count) controls implicated</span></summary><div class='scroll'><table class='cov'><thead><tr><th>Control</th><th>Name</th><th>Status</th><th>Threats</th><th>Gaps</th><th>Specific references</th></tr></thead><tbody>"
        foreach ($it in $fw.items) {
            $ag = $agg[$it.id]
            if ($ag) {
                $sev = switch ($ag.S) { 4 { 'Critical' } 3 { 'High' } 2 { 'Medium' } default { 'Low' } }
                $status = if ($ag.G.Count) { "<span class='pill $(& $sevClass $sev)'>Gap · $sev</span>" } else { "<span class='pill $(& $sevClass $sev)-soft'>At risk · $sev</span>" }
                & $A "<tr><td><b>$(& $H $it.id)</b></td><td>$(& $H $it.name)</td><td>$status</td><td>$(& $H ((@($ag.T) | Select-Object -Unique) -join ', '))</td><td>$(& $H ((@($ag.G) | Select-Object -Unique) -join ', '))</td><td class='small'>$(& $H ((@($ag.Refs) | Sort-Object) -join ', '))</td></tr>"
            } else {
                & $A "<tr class='dim'><td>$(& $H $it.id)</td><td>$(& $H $it.name)</td><td><span class='pill neutral'>Not implicated</span></td><td></td><td></td><td></td></tr>"
            }
        }
        # References the model produced that don't map to the catalog (keeps nothing hidden)
        $other = @($agg.Keys | Where-Object { $k = $_; -not (@($fw.items | Where-Object { $_.id -eq $k })) })
        foreach ($k in $other) { $ag = $agg[$k]; & $A "<tr><td><b>$(& $H $k)</b></td><td class='muted'>(unrecognised reference)</td><td></td><td>$(& $H ((@($ag.T) | Select-Object -Unique) -join ', '))</td><td>$(& $H ((@($ag.G) | Select-Object -Unique) -join ', '))</td><td></td></tr>" }
        & $A '</tbody></table></div></details>'
    }
    & $A '</section>'

    # ---------- Appendix ----------
    & $A '<section id="appendix"><h2>Appendix</h2><div class="grid2"><div class="card"><h3>Components</h3><div class="scroll"><table class="cov"><thead><tr><th>ID</th><th>Name</th><th>Type</th><th>Technology</th><th>Boundary</th><th>Data handled</th></tr></thead><tbody>'
    foreach ($c in $Model.components) { & $A "<tr><td>$($c.id)</td><td>$(& $H $c.name)</td><td>$(& $H $c.type)</td><td>$(& $H $c.technology)</td><td>$(& $H $c.trustBoundaryId)</td><td>$(& $H $c.dataHandled)</td></tr>" }
    & $A '</tbody></table></div></div><div class="card"><h3>Data flows</h3><div class="scroll"><table class="cov"><thead><tr><th>ID</th><th>From → To</th><th>Protocol</th><th>Encrypted</th><th>AuthN</th><th>Crosses boundary</th></tr></thead><tbody>'
    foreach ($f in $Model.dataFlows) {
        $enc = if ($f.encrypted -eq 'No') { "<span class='pill sev-high'>No</span>" } else { & $H $f.encrypted }
        $au  = if ($f.authenticated -eq 'No') { "<span class='pill sev-high'>No</span>" } else { & $H $f.authenticated }
        & $A "<tr><td>$($f.id)</td><td>$(& $H $compName[$f.from]) → $(& $H $compName[$f.to])<div class='small muted'>$(& $H $f.description)</div></td><td>$(& $H $f.protocol)</td><td>$enc</td><td>$au</td><td>$(if ($f.crossesTrustBoundary) { 'Yes' } else { 'No' })</td></tr>"
    }
    & $A '</tbody></table></div></div></div><div class="grid2"><div class="card"><h3>Assumptions</h3><ul>'
    foreach ($x in $Model.assumptions) { & $A "<li>$(& $H $x)</li>" }
    & $A '</ul></div><div class="card"><h3>Positive observations</h3><ul>'
    foreach ($x in $Model.positiveObservations) { & $A "<li>$(& $H $x)</li>" }
    & $A '</ul></div></div>'
    & $A "<div class='card small muted'><h3>Methodology &amp; limitations</h3><p>Generated by the AI Threat Modelling Platform using $(& $H $meta.provider) ($(& $H $meta.aiModel)), analysis depth $(& $H $meta.depth). Threats were derived with STRIDE-per-element and STRIDE-per-flow; risk = likelihood × impact scored deterministically by the platform. Findings are AI-generated from the supplied diagram/summary only and must be validated by a qualified security architect against the as-built environment before being used for compliance attestation.</p></div></section>"

    & $A ('</main><footer class="muted small">AI Threat Modelling Platform · report generated ' + (& $H $created) + '</footer>')

    # ---------- Scripts ----------
    & $A '<script>'
    & $A (Get-ReportJs)
    & $A '</script>'
    # Mermaid loader: platform copy (served) -> bundled copy relative to data/assessments/<id>/ (opened from disk) -> public CDN
    & $A '<script>(function(){var src=["/vendor/mermaid.min.js","../../../wwwroot/vendor/mermaid.min.js","https://cdn.jsdelivr.net/npm/mermaid@11/dist/mermaid.min.js"];function next(i){if(i>=src.length){document.getElementById("mm-fallback").hidden=false;return;}var s=document.createElement("script");s.src=src[i];s.onload=tmInit;s.onerror=function(){s.remove();next(i+1)};document.head.appendChild(s);}next(0);})();</script>'
    & $A '</body></html>'
    return $sb.ToString()
}

function Get-ReportCss {
@'
[hidden]{display:none!important}
:root{--bg:#f6f7f9;--card:#fff;--ink:#0f172a;--muted:#64748b;--line:#e2e8f0;--accent:#0f4c81;
--crit:#b91c1c;--high:#ea580c;--med:#ca8a04;--low:#2563eb;--none:#94a3b8}
*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.55 "Segoe UI",system-ui,-apple-system,Roboto,sans-serif}
.hdr{background:linear-gradient(120deg,#0b1f3a,#0f4c81);color:#fff}
.hdr-inner{max-width:1280px;margin:0 auto;padding:22px 24px 12px;display:flex;justify-content:space-between;gap:16px}
.eyebrow{font-size:11px;letter-spacing:.14em;text-transform:uppercase;opacity:.75}
h1{margin:4px 0 6px;font-size:26px}.hdr-meta{display:flex;flex-wrap:wrap;gap:6px 18px;font-size:12.5px;opacity:.9}
.hdr .chip{background:rgba(255,255,255,.14);color:#fff;border-color:transparent}
.toc{max-width:1280px;margin:0 auto;padding:0 24px 10px;display:flex;gap:16px;flex-wrap:wrap}
.toc a{color:#cfe3ff;text-decoration:none;font-size:13px}.toc a:hover{color:#fff}
main{max-width:1280px;margin:0 auto;padding:20px 24px 40px}section{margin:0 0 30px;scroll-margin-top:16px}
h2{font-size:19px;margin:0 0 12px}h3{font-size:15px;margin:0 0 8px}h4{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);margin:10px 0 4px}
.card{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin-bottom:14px}
.grid2{display:grid;grid-template-columns:1fr 1fr;gap:14px}.grid2>.card{margin-bottom:0}
.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:14px}
.kpi{background:var(--card);border:1px solid var(--line);border-radius:12px;padding:14px 16px}
.kpi-label{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.06em}.kpi-val{font-size:32px;font-weight:700;line-height:1.2}
.kpi-val small{font-size:14px;color:var(--muted);font-weight:500}.kpi-sub{font-size:12.5px;color:var(--muted)}
.kpi-score{border-left-width:5px}
.sevbar{display:flex;height:20px;border-radius:6px;overflow:hidden;margin-top:6px;background:#eef2f7}
.sevbar span{color:#fff;font-size:11px;font-weight:600;display:flex;align-items:center;justify-content:center;min-width:18px}
.sev-critical{background:var(--crit);color:#fff}.sev-high{background:var(--high);color:#fff}.sev-medium{background:var(--med);color:#fff}.sev-low{background:var(--low);color:#fff}.sev-none{background:var(--none)}
.sev-critical-border{border-left:5px solid var(--crit)}.sev-high-border{border-left:5px solid var(--high)}.sev-medium-border{border-left:5px solid var(--med)}.sev-low-border{border-left:5px solid var(--low)}
.sev-critical-soft{background:#fde2e2}.sev-high-soft{background:#ffe9d6}.sev-medium-soft{background:#fdf3c4}.sev-low-soft{background:#dfeafe}
.pill{display:inline-block;padding:1px 9px;border-radius:999px;font-size:11.5px;font-weight:600;white-space:nowrap}
.pill.neutral{background:#eef2f7;color:#334155}.pill.sev-critical-soft,.pill.sev-high-soft,.pill.sev-medium-soft,.pill.sev-low-soft{color:#0f172a}
.chip{display:inline-block;border:1px solid var(--line);background:#f1f5f9;border-radius:6px;padding:1px 7px;margin:2px 4px 2px 0;font-size:11.5px;font-family:Consolas,ui-monospace,monospace}
.chips{margin-top:8px}.c-owasp,.c-owasp_llm{background:#fff1f2;border-color:#fecdd3}.c-cis{background:#ecfdf5;border-color:#a7f3d0}.c-nist_csf,.c-nist_80053{background:#eff6ff;border-color:#bfdbfe}.c-mcsb{background:#f5f3ff;border-color:#ddd6fe}
.mapline{margin-bottom:4px}.maplbl{display:inline-block;min-width:74px;font-size:11px;color:var(--muted);font-weight:600}
.muted{color:var(--muted)}.small{font-size:12px}
.stride-bars .sb-row{display:grid;grid-template-columns:22px 160px 1fr 30px;align-items:center;gap:8px;margin:6px 0}
.sb-k{font-weight:700;color:var(--accent)}.sb-track{background:#eef2f7;height:10px;border-radius:5px;overflow:hidden}.sb-fill{display:block;height:100%;background:var(--accent)}.sb-v{text-align:right;font-weight:600}
.toprisks li{margin:5px 0}
.sec-head{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap}
button{background:var(--accent);color:#fff;border:0;border-radius:8px;padding:7px 14px;font:inherit;font-size:13px;cursor:pointer}button:hover{filter:brightness(1.1)}
.hdr button{background:#fff;color:var(--accent)}
.legend{display:flex;flex-wrap:wrap;gap:14px;align-items:center;font-size:12.5px;margin:6px 0 10px}.sw{display:inline-block;width:12px;height:12px;border-radius:3px;margin-right:5px;vertical-align:-1px}
.diagram{overflow:auto;background:#fbfcfe}.diagram pre.mermaid{margin:0;text-align:center;background:none}
.archimg{max-width:100%;border:1px solid var(--line);border-radius:8px}figure{margin:0 0 10px}figcaption{font-size:12px;color:var(--muted)}
.scroll{overflow-x:auto}table{border-collapse:collapse;width:100%}th,td{padding:7px 9px;border-bottom:1px solid var(--line);text-align:left;vertical-align:top}
th{font-size:12px;color:var(--muted);font-weight:600;background:#f8fafc}
table.heat td.hc{text-align:center;font-weight:700;width:90px}table.heat td.empty{color:#cbd5e1}table.heat th{text-align:center}table.heat th:first-child{text-align:left}.hc-total{text-align:center;font-weight:700}
table.riskm{width:auto}table.riskm td.rm{width:150px;height:62px;font-size:12px;font-weight:600;border:2px solid #fff;position:relative}.rm-score{position:absolute;right:6px;bottom:3px;font-size:10px;opacity:.5}th.axis{background:none;text-align:center}
.filters{display:flex;gap:8px;flex-wrap:wrap}.filters input,.filters select{padding:6px 10px;border:1px solid var(--line);border-radius:8px;font:inherit;font-size:13px;background:#fff}
.trow{cursor:pointer}.trow:hover{background:#f8fafc}.stride{display:inline-block;width:20px;height:20px;line-height:20px;text-align:center;border-radius:4px;background:#0f4c81;color:#fff;font-size:11px;font-weight:700;margin-right:3px}
.tdetail td{background:#fbfcfe}.detail-grid,.gap-grid{display:grid;grid-template-columns:1.3fr 1.2fr 1fr;gap:18px}.detail-grid ul,.gap-grid ul{margin:0;padding-left:18px}
.roadmap{display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:6px}.rm-col ul{list-style:none;padding:0;margin:0}.rm-col li{margin:5px 0;font-size:13px}
.dot{display:inline-block;width:9px;height:9px;border-radius:50%;margin-right:6px}
.gap-head{display:flex;justify-content:space-between;gap:10px;flex-wrap:wrap;margin-bottom:4px}.gid{font-family:Consolas,monospace;color:var(--muted)}
details.fw summary{cursor:pointer;font-size:15px;margin-bottom:8px}tr.dim td{color:#94a3b8}
footer{text-align:center;padding:20px}
@media (max-width:900px){.grid2,.kpis,.roadmap,.detail-grid,.gap-grid{grid-template-columns:1fr}.hdr{position:static}}
@media print{.no-print{display:none!important}.hdr{position:static;-webkit-print-color-adjust:exact;print-color-adjust:exact}body{background:#fff}
.card,.kpi{break-inside:avoid}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}.tdetail{display:table-row!important}.tdetail[hidden]{display:table-row!important}}
'@
}

function Get-ReportJs {
@'
function toggleRow(tr){const d=tr.nextElementSibling;if(d&&d.classList.contains('tdetail'))d.hidden=!d.hidden;}
let allOpen=false;function toggleAll(){allOpen=!allOpen;document.querySelectorAll('.tdetail').forEach(d=>{if(d.previousElementSibling.style.display!=='none')d.hidden=!allOpen;});}
function filterThreats(){const q=document.getElementById('tq').value.toLowerCase().trim(),s=document.getElementById('tsev').value,st=document.getElementById('tstr').value;
document.querySelectorAll('#treg tr.trow').forEach(r=>{const ok=(!q||r.dataset.q.includes(q))&&(!s||r.dataset.sev===s)&&(!st||r.dataset.stride.includes(st));r.style.display=ok?'':'none';if(!ok)r.nextElementSibling.hidden=true;});}
function downloadSvg(){const svg=document.querySelector('#threatmap svg');if(!svg){alert('Diagram not rendered.');return;}
const blob=new Blob([new XMLSerializer().serializeToString(svg)],{type:'image/svg+xml'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='threat-map.svg';a.click();}
function tmInit(){if(!window.mermaid){document.getElementById('mm-fallback').hidden=false;return;}
mermaid.initialize({startOnLoad:false,securityLevel:'strict',theme:'base',maxTextSize:200000,flowchart:{htmlLabels:true,curve:'basis',nodeSpacing:45,rankSpacing:70,padding:12},
themeVariables:{fontFamily:'Segoe UI, system-ui, sans-serif',fontSize:'13px',clusterBkg:'#eef4fb',clusterBorder:'#7aa2cf',lineColor:'#64748b',edgeLabelBackground:'#ffffff'}});
mermaid.run({querySelector:'#threatmap'}).catch(e=>{console.error(e);document.getElementById('mm-fallback').hidden=false;});}
'@
}
