'use strict';
/* AI Threat Modelling Platform – front-end (no build step, no external dependencies) */

const $ = (s, el = document) => el.querySelector(s);
const $$ = (s, el = document) => [...el.querySelectorAll(s)];
const esc = v => String(v ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

const state = { config: null, images: [], pollTimer: null, histTimer: null, items: [] };
const MAX_EDGE = 4000;          // px – long edge after optimisation
const MAX_BYTES = 4.5 * 1024 * 1024;
const LLM_HINT = /\b(llm|gpt|openai|copilot|rag|vector|embedding|agent(ic)?|chatbot|prompt|foundry|bedrock|gemini|claude)\b/i;

/* ---------------- API ---------------- */
async function api(path, opts = {}) {
  const res = await fetch(path, { headers: { 'Content-Type': 'application/json' }, ...opts });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

/* ---------------- Navigation ---------------- */
function show(view) {
  $$('.view').forEach(v => v.hidden = v.id !== `view-${view}`);
  $$('.tab').forEach(t => t.classList.toggle('active', t.dataset.view === view));
  if (view === 'history') loadHistory();
  history.replaceState(null, '', view === 'new' ? '#' : `#${view}`);
}
$$('.tab').forEach(t => t.addEventListener('click', () => show(t.dataset.view)));

/* ---------------- Config / frameworks ---------------- */
async function init() {
  try {
    state.config = await api('/api/config');
  } catch (e) { $('#formError').textContent = 'Cannot reach the platform API: ' + e.message; $('#formError').hidden = false; return; }
  const c = state.config;
  $('#whoUser').textContent = c.user || '';
  $('#whoProvider').textContent = `AI: ${c.provider} · ${c.model || ''}`;
  $('#providerName2').textContent = `${c.provider}${c.model ? ' – ' + c.model : ''}`;
  const list = $('#fwList');
  list.innerHTML = c.frameworks.map(f => `
    <label class="fw ${f.alwaysOn ? 'locked' : ''}">
      <input type="checkbox" name="fw" value="${esc(f.key)}" ${f.alwaysOn || !f.optional ? 'checked' : ''} ${f.alwaysOn ? 'disabled' : ''}>
      <span>${esc(f.name)}<small>${esc(f.version)}${f.alwaysOn ? ' · always applied' : ''}</small></span>
    </label>`).join('');
  if (location.hash === '#history') show('history');
  refreshRunningBadge();
}

/* ---------------- Images ---------------- */
const dz = $('#dropzone'), fileInput = $('#fileInput');
dz.addEventListener('click', () => fileInput.click());
dz.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); } });
fileInput.addEventListener('change', () => { addFiles(fileInput.files); fileInput.value = ''; });
['dragenter', 'dragover'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.add('drag'); }));
['dragleave', 'drop'].forEach(ev => dz.addEventListener(ev, e => { e.preventDefault(); dz.classList.remove('drag'); }));
dz.addEventListener('drop', e => addFiles(e.dataTransfer.files));
document.addEventListener('paste', e => {
  if (!$('#view-new').hidden && e.clipboardData) {
    const files = [...e.clipboardData.items].filter(i => i.type.startsWith('image/')).map(i => i.getAsFile());
    if (files.length) { e.preventDefault(); addFiles(files); }
  }
});

async function addFiles(fileList) {
  const allowed = ['image/png', 'image/jpeg', 'image/gif', 'image/webp'];
  for (const f of [...fileList]) {
    if (state.images.length >= (state.config?.maxImages || 5)) { formError(`Maximum ${state.config?.maxImages || 5} images.`); break; }
    if (!allowed.includes(f.type)) { formError(`${f.name}: unsupported type. Use PNG, JPG, GIF or WEBP (export Visio/draw.io diagrams as PNG).`); continue; }
    try { state.images.push(await prepareImage(f)); } catch (e) { formError(`${f.name}: ${e.message}`); }
  }
  renderThumbs();
}

function loadImg(src) { return new Promise((ok, fail) => { const i = new Image(); i.onload = () => ok(i); i.onerror = () => fail(new Error('could not be read as an image')); i.src = src; }); }
function readDataUrl(blob) { return new Promise((ok, fail) => { const r = new FileReader(); r.onload = () => ok(r.result); r.onerror = fail; r.readAsDataURL(blob); }); }

async function prepareImage(file) {
  let dataUrl = await readDataUrl(file);
  const img = await loadImg(dataUrl);
  let note = `${img.naturalWidth}×${img.naturalHeight}`;
  const tooBig = Math.max(img.naturalWidth, img.naturalHeight) > MAX_EDGE || file.size > MAX_BYTES;
  let type = file.type;
  if (tooBig && file.type !== 'image/gif') {
    const scale = Math.min(1, MAX_EDGE / Math.max(img.naturalWidth, img.naturalHeight));
    const cv = document.createElement('canvas');
    cv.width = Math.round(img.naturalWidth * scale); cv.height = Math.round(img.naturalHeight * scale);
    const ctx = cv.getContext('2d'); ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, cv.width, cv.height); ctx.drawImage(img, 0, 0, cv.width, cv.height);
    dataUrl = cv.toDataURL('image/png'); type = 'image/png';
    if (dataUrl.length * 0.75 > MAX_BYTES) { dataUrl = cv.toDataURL('image/jpeg', 0.92); type = 'image/jpeg'; }
    note = `optimised to ${cv.width}×${cv.height}`;
  }
  return { fileName: file.name || 'pasted-image.png', mediaType: type, data: dataUrl.split(',')[1], preview: dataUrl, note };
}

function renderThumbs() {
  $('#thumbs').innerHTML = state.images.map((im, i) => `
    <div class="thumb"><img src="${im.preview}" alt=""><div class="cap" title="${esc(im.fileName)}">${esc(im.fileName)} · ${esc(im.note)}</div>
    <button type="button" data-rm="${i}" aria-label="Remove">×</button></div>`).join('');
  $$('#thumbs [data-rm]').forEach(b => b.addEventListener('click', () => { state.images.splice(+b.dataset.rm, 1); renderThumbs(); }));
}

/* ---------------- Summary ---------------- */
const summary = $('#summary');
const updateCount = () => {
  $('#charCount').textContent = summary.value.length.toLocaleString();
  const llm = $('input[name=fw][value=OWASP_LLM]');
  if (llm && !llm.dataset.touched && LLM_HINT.test(summary.value)) llm.checked = true;
};
summary.addEventListener('input', updateCount);
$('#loadSummary').addEventListener('click', () => $('#summaryFile').click());
$('#summaryFile').addEventListener('change', async e => {
  const f = e.target.files[0]; if (!f) return;
  if (f.size > 500000) { formError('Summary file too large (max ~500 KB).'); return; }
  summary.value = await f.text(); updateCount(); e.target.value = '';
});
$('#templateBtn').addEventListener('click', () => {
  if (summary.value.trim() && !confirm('Replace the current summary with the template?')) return;
  summary.value = $('#summaryTemplate').content.textContent; updateCount(); summary.focus();
});
document.addEventListener('change', e => { if (e.target.name === 'fw') e.target.dataset.touched = '1'; });

/* ---------------- Submit ---------------- */
function formError(msg) { const el = $('#formError'); el.textContent = msg; el.hidden = !msg; }

$('#assessForm').addEventListener('submit', async e => {
  e.preventDefault(); formError('');
  const fd = new FormData(e.target);
  const name = (fd.get('name') || '').trim();
  if (!name) { formError('Please enter the system / application name.'); $('input[name=name]').focus(); return; }
  if (!state.images.length && !summary.value.trim()) { formError('Upload at least one architecture diagram or enter an architecture summary.'); return; }
  const payload = {
    name, owner: fd.get('owner'), environment: fd.get('environment'), criticality: fd.get('criticality'),
    dataClassification: fd.get('dataClassification'), depth: fd.get('depth'),
    frameworks: $$('input[name=fw]:checked:not(:disabled)').map(x => x.value),
    summary: summary.value,
    images: state.images.map(({ fileName, mediaType, data }) => ({ fileName, mediaType, data }))
  };
  const btn = $('#submitBtn'); btn.disabled = true; btn.textContent = 'Uploading…';
  try {
    const r = await api('/api/assessments', { method: 'POST', body: JSON.stringify(payload) });
    startProgress(r.id, name);
  } catch (err) { formError(err.message); }
  finally { btn.disabled = false; btn.textContent = 'Generate threat model'; }
});

function startProgress(id, name) {
  $('#assessForm').hidden = true; $('#progress').hidden = false;
  $('#progTitle').textContent = `Threat modelling “${name}”`;
  $$('.stages li').forEach(li => li.className = '');
  clearInterval(state.pollTimer);
  const poll = async () => {
    try {
      const s = await api(`/api/assessments/${encodeURIComponent(id)}`);
      const order = ['Queued', 'Analyzing', 'Rendering', 'Completed'];
      const idx = order.indexOf(s.state);
      $$('.stages li').forEach((li, i) => {
        li.className = s.state === 'Failed' ? (i === 0 ? 'done' : (i === 1 ? 'failed' : '')) : (i < idx || s.state === 'Completed' ? 'done' : i === idx ? 'active' : '');
      });
      $('#progMsg').textContent = s.message || '';
      if (s.state === 'Completed') { clearInterval(state.pollTimer); setTimeout(() => openReport(s), 700); resetForm(); }
      if (s.state === 'Failed') { clearInterval(state.pollTimer); $('#progTitle').textContent = 'Assessment failed'; }
      refreshRunningBadge();
    } catch (e) { $('#progMsg').textContent = e.message; }
  };
  poll(); state.pollTimer = setInterval(poll, 2500);
}

function resetForm() {
  $('#assessForm').reset(); state.images = []; renderThumbs(); updateCount();
  $$('input[name=fw]').forEach(x => delete x.dataset.touched);
}
$('#newAnother').addEventListener('click', () => { clearInterval(state.pollTimer); $('#progress').hidden = true; $('#assessForm').hidden = false; });

/* ---------------- History ---------------- */
const fmtDate = s => { try { return new Date(s).toLocaleString(undefined, { day: '2-digit', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }); } catch { return s; } };
const running = s => ['Queued', 'Analyzing', 'Rendering'].includes(s);

async function loadHistory() {
  try {
    const r = await api('/api/assessments');
    state.items = r.items || [];
    renderHistory();
    clearTimeout(state.histTimer);
    if (state.items.some(i => running(i.state)) && !$('#view-history').hidden) state.histTimer = setTimeout(loadHistory, 4000);
  } catch (e) { $('#histBody').innerHTML = `<tr><td colspan="7" class="failmsg">${esc(e.message)}</td></tr>`; }
  refreshRunningBadge();
}

function renderHistory() {
  const q = $('#histSearch').value.toLowerCase().trim();
  const rows = state.items.filter(i => !q || [i.name, i.owner, i.id, i.requestedBy, i.environment].join(' ').toLowerCase().includes(q));
  if (!rows.length) { $('#histBody').innerHTML = `<tr><td colspan="7" class="muted">${state.items.length ? 'No matches.' : 'No assessments yet — start one from “New assessment”.'}</td></tr>`; return; }
  $('#histBody').innerHTML = rows.map(i => {
    const done = i.state === 'Completed';
    const inputs = [i.imageCount ? `${i.imageCount} image${i.imageCount > 1 ? 's' : ''}` : '', i.hasSummary ? 'summary' : ''].filter(Boolean).join(' + ');
    return `<tr class="${done ? 'clickable' : ''}" data-id="${esc(i.id)}">
      <td><b>${esc(i.name)}</b><div class="muted small">${esc(i.environment)} · ${esc(i.owner || '—')} · <span class="mono">${esc(i.id)}</span></div><div class="muted small">${esc(inputs)} · ${esc(i.depth)}</div></td>
      <td class="small">${esc(fmtDate(i.createdAt))}<div class="muted">${esc(i.requestedBy || '')}</div></td>
      <td><span class="pill st-${esc(i.state)}">${esc(i.state)}</span>${i.state === 'Failed' ? `<div class="failmsg">${esc(i.message)}</div>` : ''}${done && i.durationSec ? `<div class="muted small">${i.durationSec}s</div>` : ''}</td>
      <td>${done ? `<span class="score">${esc(i.exposureScore)}</span><span class="pill sev-${esc(i.exposureRating)}">${esc(i.exposureRating)}</span>` : ''}</td>
      <td class="cnt">${done ? `${esc(i.threats)} <small>(${esc(i.critical)} C · ${esc(i.high)} H)</small>` : ''}</td>
      <td class="cnt">${done ? esc(i.gaps) : ''}</td>
      <td><div class="actions">
        ${done ? `<button class="btn-ghost" data-open="${esc(i.id)}">Open</button><a class="btn-ghost" href="/reports/${encodeURIComponent(i.id)}/gaps.csv">Gaps CSV</a>` : ''}
        ${state.config?.allowDelete && !running(i.state) ? `<button class="btn-ghost btn-danger" data-del="${esc(i.id)}" title="Delete">✕</button>` : ''}
      </div></td></tr>`;
  }).join('');
  $$('#histBody [data-open], #histBody tr.clickable').forEach(el => el.addEventListener('click', e => {
    if (e.target.closest('a,[data-del]')) return;
    const id = el.dataset.open || el.dataset.id; const it = state.items.find(x => x.id === id); if (it) openReport(it);
  }));
  $$('#histBody [data-del]').forEach(b => b.addEventListener('click', async e => {
    e.stopPropagation();
    if (!confirm(`Delete assessment ${b.dataset.del}? This removes the report and uploaded inputs.`)) return;
    try { await api(`/api/assessments/${encodeURIComponent(b.dataset.del)}`, { method: 'DELETE' }); loadHistory(); } catch (err) { alert(err.message); }
  }));
}
$('#histSearch').addEventListener('input', renderHistory);

async function refreshRunningBadge() {
  try {
    const items = state.items.length ? state.items : (await api('/api/assessments')).items || [];
    const n = items.filter(i => running(i.state)).length;
    const b = $('#runningBadge'); b.textContent = `${n} running`; b.hidden = n === 0;
  } catch { /* ignore */ }
}

/* ---------------- Report viewer ---------------- */
function openReport(it) {
  $$('.view').forEach(v => v.hidden = v.id !== 'view-report');
  $$('.tab').forEach(t => t.classList.remove('active'));
  $('#rptName').textContent = it.name; $('#rptId').textContent = it.id;
  const base = `/reports/${encodeURIComponent(it.id)}`;
  const files = it.files || ['report.html', 'threats.csv', 'gaps.csv', 'model.json', 'diagram.mmd'];
  const label = { 'report.html': 'Download HTML', 'threats.csv': 'Threats CSV', 'gaps.csv': 'Gaps CSV', 'threat-model.xlsx': 'Excel', 'model.json': 'JSON', 'diagram.mmd': 'Mermaid' };
  $('#rptActions').innerHTML = `<a class="btn-ghost" href="${base}/report.html" target="_blank" rel="noopener">Open in new tab ↗</a>` +
    files.filter(f => label[f]).map(f => `<a class="btn-ghost" href="${base}/${f}${f === 'report.html' ? '?download=1' : ''}">${label[f]}</a>`).join('');
  $('#rptFrame').src = `${base}/report.html`;
  window.scrollTo(0, 0);
}
$('#backBtn').addEventListener('click', () => { $('#rptFrame').src = 'about:blank'; show('history'); });

init();
